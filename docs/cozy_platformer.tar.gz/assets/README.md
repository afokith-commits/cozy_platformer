# Sproutbound 🌱

A cozy micro-platformer built with Pygame & Python.

---

## 🚀 How Your Friend Can Play (KISS — Keep It Simple!)

### 1. Download / Clone the folder
Send your friend this repository link or zip up the project folder.

### 2. Run the Game

- **Windows**: Double-click `run_game.bat` (It will install `pygame` automatically if needed and launch the game!).
- **Mac / Linux**: Double-click `run_game.sh` or run `python3 main.py`.

---

## 🕹️ Game Controls

| Action | Controls |
|---|---|
| **Move** | <kbd>A</kbd> / <kbd>D</kbd> or <kbd>←</kbd> / <kbd>→</kbd> |
| **Jump / Wall Jump** | <kbd>Space</kbd> or <kbd>W</kbd> / <kbd>↑</kbd> |
| **Interact (NPC / Shrines)** | <kbd>E</kbd> |
| **Inventory** | <kbd>Tab</kbd> |
| **Pause Menu** | <kbd>Esc</kbd> |

---

## 🛠️ System Requirements
- Python 3.9+
- `pygame` (`pip install pygame`)
